import sys
import time

def cursor():
    while True:
        for arow in '|/-\\':
            yield arow

spinner = cursor()
for arow in range(10):
    sys.stdout.write(next(spinner))
    sys.stdout.flush()
    time.sleep(0.5)
    sys.stdout.write('\r')