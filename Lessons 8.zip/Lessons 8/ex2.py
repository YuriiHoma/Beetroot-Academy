europe = {"Ukraine": { "capital":"Kiyv" },
           "Poland": { "capital":"Varshava" },
           'Germany': { "capital":"Berlin" },
           'France': { "capital":"Paris",  } }


print(europe["Poland"]["capital"])

print(europe)