from multiprocessing import Value


def make_operation(*args):
    return_value = 0
    for number in args:
        return_value += number
    return return_value
     

print(make_operation(7, 7, 2 ))





