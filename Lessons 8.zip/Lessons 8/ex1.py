def favorite_movie(movie):
    print("My favorite movie is named " + movie )
 
favorite_movie("Van Helsing")