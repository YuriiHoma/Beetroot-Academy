import random
word = "Hello"
another = list(word)
The_end = random.sample(another, len(another))
print(The_end)