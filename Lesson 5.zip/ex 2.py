First_name = input('Enter name: ')
age = input('Enter age: ')
print("Hello, " + str(First_name), "your next birthday you will be," +str(age), "years!")





