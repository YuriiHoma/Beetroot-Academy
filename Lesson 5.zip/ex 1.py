answer = True
while answer:
    x = int(input('Enter number: ' ))
    if x == 7:
        print('Winner')
        answer = False
    else:
        print ('try again')
        continue

