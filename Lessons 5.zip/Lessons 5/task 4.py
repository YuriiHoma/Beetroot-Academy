from calendar import week, weekheader

list = [
    'Monday:' , 
    'Tuesday:', 
    'Wedsday:', 
    'Thursday:', 
    'Friday:', 
    'Saturday:', 
    'Sunday:' 
]
for i, week in enumerate (list):
    list, i = (week, i+0)
    print(week, i+1)


